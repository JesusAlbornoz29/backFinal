package com.example.FinalDesdeCero.repository;

import com.example.FinalDesdeCero.entity.Turno;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ITurnoRepository extends JpaRepository<Turno, Long> {
}

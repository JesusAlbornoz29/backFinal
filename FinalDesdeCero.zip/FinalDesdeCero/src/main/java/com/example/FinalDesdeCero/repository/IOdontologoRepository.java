package com.example.FinalDesdeCero.repository;

import com.example.FinalDesdeCero.entity.Odontologo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IOdontologoRepository extends JpaRepository<Odontologo,Long> {
}
